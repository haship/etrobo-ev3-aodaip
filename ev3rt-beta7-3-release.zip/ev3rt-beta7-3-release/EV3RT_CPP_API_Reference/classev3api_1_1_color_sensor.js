var classev3api_1_1_color_sensor =
[
    [ "ColorSensor", "classev3api_1_1_color_sensor.html#aa04568c513529526d82dab6be9d78f52", null ],
    [ "~ColorSensor", "classev3api_1_1_color_sensor.html#aaf93ee90a67ca04c75c5ea13a8ebf1cf", null ],
    [ "getAmbient", "classev3api_1_1_color_sensor.html#ac628445a89816779064557d74edadbae", null ],
    [ "getBrightness", "classev3api_1_1_color_sensor.html#ae7c90ed5da0316e75d4e47cd0c65b292", null ],
    [ "getColorNumber", "classev3api_1_1_color_sensor.html#a1e9c3f8e0d18c579b99fb21b838fa01f", null ],
    [ "getRawColor", "classev3api_1_1_color_sensor.html#a1dee9103ba1bbbcf732e0470681b52b4", null ]
];
var classev3api_1_1_steering =
[
    [ "Steering", "classev3api_1_1_steering.html#a949e48c5ff386868e918cfb468ac3f1d", null ],
    [ "setPower", "classev3api_1_1_steering.html#a1d154bc23a2a621a810eecd47290c597", null ]
];
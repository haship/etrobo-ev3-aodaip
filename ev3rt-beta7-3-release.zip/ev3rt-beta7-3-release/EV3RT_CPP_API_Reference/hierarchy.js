var hierarchy =
[
    [ "Clock", "classev3api_1_1_clock.html", null ],
    [ "Motor", "classev3api_1_1_motor.html", null ],
    [ "Sensor", "classev3api_1_1_sensor.html", [
      [ "ColorSensor", "classev3api_1_1_color_sensor.html", null ],
      [ "GyroSensor", "classev3api_1_1_gyro_sensor.html", null ],
      [ "SonarSensor", "classev3api_1_1_sonar_sensor.html", null ],
      [ "TouchSensor", "classev3api_1_1_touch_sensor.html", null ]
    ] ],
    [ "Steering", "classev3api_1_1_steering.html", null ]
];
var searchData=
[
  ['getambient',['getAmbient',['../classev3api_1_1_color_sensor.html#ac628445a89816779064557d74edadbae',1,'ev3api::ColorSensor']]],
  ['getangle',['getAngle',['../classev3api_1_1_gyro_sensor.html#a0b7565236adfa4db73dac15fe0694a08',1,'ev3api::GyroSensor']]],
  ['getanglervelocity',['getAnglerVelocity',['../classev3api_1_1_gyro_sensor.html#aa21d430c7b34346a7462150008c987fe',1,'ev3api::GyroSensor']]],
  ['getbrake',['getBrake',['../classev3api_1_1_motor.html#a245dfc222f44cef62362285c8b19ef40',1,'ev3api::Motor']]],
  ['getbrightness',['getBrightness',['../classev3api_1_1_color_sensor.html#ae7c90ed5da0316e75d4e47cd0c65b292',1,'ev3api::ColorSensor']]],
  ['getcolornumber',['getColorNumber',['../classev3api_1_1_color_sensor.html#a1e9c3f8e0d18c579b99fb21b838fa01f',1,'ev3api::ColorSensor']]],
  ['getcount',['getCount',['../classev3api_1_1_motor.html#a96ed2a8a58884ae715f48a4034873cc7',1,'ev3api::Motor']]],
  ['getdistance',['getDistance',['../classev3api_1_1_sonar_sensor.html#a77255b0ca7d23f1c2e8f7a22a64c353a',1,'ev3api::SonarSensor']]],
  ['getport',['getPort',['../classev3api_1_1_motor.html#a1db6b0a0bdf33bc2c62bfff0320c8424',1,'ev3api::Motor::getPort()'],['../classev3api_1_1_sensor.html#afa70172de3db66892b394dbb8ba0b575',1,'ev3api::Sensor::getPort()']]],
  ['getpwm',['getPWM',['../classev3api_1_1_motor.html#a2d54cba94837c578415bd3d1c180ec45',1,'ev3api::Motor']]],
  ['getrawcolor',['getRawColor',['../classev3api_1_1_color_sensor.html#a1dee9103ba1bbbcf732e0470681b52b4',1,'ev3api::ColorSensor']]],
  ['gettim',['getTim',['../classev3api_1_1_clock.html#a6481c3c7e9168faff019887c77b43872',1,'ev3api::Clock']]],
  ['gyrosensor',['GyroSensor',['../classev3api_1_1_gyro_sensor.html#a4b5eceaa0d59fa77de4a9389c47cf100',1,'ev3api::GyroSensor']]]
];

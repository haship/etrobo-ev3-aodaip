var searchData=
[
  ['wait',['wait',['../classev3api_1_1_clock.html#a611ef76a63a6c2d2b217333f325e07a5',1,'ev3api::Clock']]]
];

var structimage__t =
[
    [ "data", "structimage__t.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "height", "structimage__t.html#a5d8006e753a3e76ff637a4e092bbed71", null ],
    [ "width", "structimage__t.html#a395d15e7c2b09961c1bfd1da6179b64c", null ]
];
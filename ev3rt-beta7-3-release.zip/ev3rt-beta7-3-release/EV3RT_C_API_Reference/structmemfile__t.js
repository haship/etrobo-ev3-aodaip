var structmemfile__t =
[
    [ "buffer", "structmemfile__t.html#a368f7094dc38acca20612bbb392552f4", null ],
    [ "buffersz", "structmemfile__t.html#a4741a4da4c1364a2940b4815a50764d0", null ],
    [ "filesz", "structmemfile__t.html#a523b3798dc64d2e36483e66196110e82", null ]
];
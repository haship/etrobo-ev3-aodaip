var group__ev3rt__battery =
[
    [ "ev3_battery_current_mA", "group__ev3rt__battery.html#gaa88ba0054f5215fa0ef1527afcab6ebc", null ],
    [ "ev3_battery_voltage_mV", "group__ev3rt__battery.html#ga80698b59a9f94a751891cebf963cf319", null ]
];
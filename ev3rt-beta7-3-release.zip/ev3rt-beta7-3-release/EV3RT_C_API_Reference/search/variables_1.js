var searchData=
[
  ['channel',['channel',['../structir__remote__t.html#ac807969279ec280acf6377e0236a5273',1,'ir_remote_t']]]
];

var searchData=
[
  ['fileinfo_5ft',['fileinfo_t',['../structfileinfo__t.html',1,'']]],
  ['filesz',['filesz',['../structmemfile__t.html#a523b3798dc64d2e36483e66196110e82',1,'memfile_t']]]
];

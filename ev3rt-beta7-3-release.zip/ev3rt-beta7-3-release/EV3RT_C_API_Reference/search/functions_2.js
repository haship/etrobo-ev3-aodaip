var searchData=
[
  ['nxt_5ftemp_5fsensor_5fmeasure',['nxt_temp_sensor_measure',['../group__ev3sensor.html#ga0ec1343baa9ff742a9d2354af9b601f4',1,'nxt_temp_sensor_measure(sensor_port_t port, float *temp):&#160;ev3api_sensor.c'],['../group__ev3sensor.html#ga0ec1343baa9ff742a9d2354af9b601f4',1,'nxt_temp_sensor_measure(sensor_port_t port, float *temp):&#160;ev3api_sensor.c']]]
];

var annotated_dup =
[
    [ "fileinfo_t", "structfileinfo__t.html", "structfileinfo__t" ],
    [ "image_t", "structimage__t.html", "structimage__t" ],
    [ "ir_remote_t", "structir__remote__t.html", "structir__remote__t" ],
    [ "ir_seek_t", "structir__seek__t.html", "structir__seek__t" ],
    [ "memfile_t", "structmemfile__t.html", "structmemfile__t" ],
    [ "rgb_raw_t", "structrgb__raw__t.html", "structrgb__raw__t" ],
    [ "STEPSPEED", "struct_s_t_e_p_s_p_e_e_d.html", "struct_s_t_e_p_s_p_e_e_d" ],
    [ "STEPSYNC", "struct_s_t_e_p_s_y_n_c.html", "struct_s_t_e_p_s_y_n_c" ]
];
var group__ev3button =
[
    [ "button_t", "group__ev3button.html#ga7754652ebe470fb6cc5d30b4cd258660", [
      [ "LEFT_BUTTON", "group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660acc7c999423bde38a6b6156b77c4f194e", null ],
      [ "RIGHT_BUTTON", "group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660a2f7db56ce29bb4a148cae5ab0198709a", null ],
      [ "UP_BUTTON", "group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660a308e2dec294b93e1c691bacd5cd45266", null ],
      [ "DOWN_BUTTON", "group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660a4ef6f8a30edabae1ea534aa7c4f79199", null ],
      [ "ENTER_BUTTON", "group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660ab42cc4bbdbed78b08763c32419fb5796", null ],
      [ "BACK_BUTTON", "group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660a46cf6c1da23c500cd1369fa994f902fb", null ],
      [ "TNUM_BUTTON", "group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660af198627fc8492ff6a8bc7329f5d720da", null ]
    ] ],
    [ "ev3_button_is_pressed", "group__ev3button.html#ga58698096470ad567a785e82cd2514ced", null ],
    [ "ev3_button_set_on_clicked", "group__ev3button.html#gaf2da803506b62a1f3180e182f504ff80", null ]
];
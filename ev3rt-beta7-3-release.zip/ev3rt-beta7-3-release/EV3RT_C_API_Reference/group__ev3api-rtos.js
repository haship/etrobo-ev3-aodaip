var group__ev3api_rtos =
[
    [ "ev3_sta_cyc", "group__ev3api-rtos.html#ga7f51f241ca2b6283af7c5bd2ff843548", null ],
    [ "ev3_stp_cyc", "group__ev3api-rtos.html#gaf57b142403f4c55309dafd0855a003e0", null ]
];